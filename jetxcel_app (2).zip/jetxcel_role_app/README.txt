Jetxcel Role App (Cliente/Admin)
--------------------------------
- Login con roles (cliente / admin) desde data/users.json
- Cliente: crea PQRS, lista sus casos, exporta CSV
- Admin: ve todos, edita seguimiento (estado/acción/fecha), métricas, exporta CSV
- Persistencia en archivos JSON (data/datos.json)

Cómo ejecutar:
  npm install
  node server.js
  Abrir http://127.0.0.1:3000

Credenciales demo:
  Cliente -> usuario: cliente  contraseña: jetxcel2025
  Admin   -> usuario: admin    contraseña: jetxcelAdmin2025

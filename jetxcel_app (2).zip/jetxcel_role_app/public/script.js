// Role-based client logic for Jetxcel app
function $(sel){return document.querySelector(sel);}
function escapeHtml(s){ if(s==null) return ''; return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;').replace(/'/g,'&#039;'); }

// Tabs on landing
document.addEventListener('DOMContentLoaded', () => {
  const tabs = document.querySelectorAll('.tab');
  tabs.forEach(t => t?.addEventListener('click', () => {
    tabs.forEach(x => x.classList.remove('active'));
    t.classList.add('active');
    const role = t.dataset.role;
    const roleInput = document.getElementById('role');
    if (roleInput) roleInput.value = role === 'admin' ? 'admin' : 'client';
  }));

  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const user = document.getElementById('user').value.trim();
      const pass = document.getElementById('pass').value.trim();
      const role = (document.getElementById('role').value || 'client').trim();
      const err = document.getElementById('loginError');
      err.textContent = '';

      try {
        const res = await fetch('/api/login', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ user, pass, role })
        });
        const data = await res.json();
        if (!data.success){ err.textContent = data.message || 'Credenciales inválidas'; return; }
        localStorage.setItem('jx_user', data.user);
        localStorage.setItem('jx_role', data.role);
        window.location.href = data.role === 'admin' ? '/admin.html' : '/client.html';
      } catch (e) {
        err.textContent = 'Error de conexión con el servidor';
      }
    });
  }

  // CLIENT PAGE
  if (location.pathname.endsWith('/client.html')) {
    const who = document.getElementById('who');
    const user = localStorage.getItem('jx_user') || 'cliente';
    if (who) who.textContent = 'Conectado como: ' + user;

    const pqrsForm = document.getElementById('pqrsForm');
    pqrsForm?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const status = document.getElementById('statusMsg');
      status.textContent = 'Enviando...';
      const payload = {
        owner: user,
        nombre: document.getElementById('nombre').value.trim(),
        email: document.getElementById('email').value.trim(),
        tipo: document.getElementById('tipo').value,
        mensaje: document.getElementById('mensaje').value.trim(),
      };
      try{
        const res = await fetch('/api/pqrs', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
        const out = await res.json();
        if(out.success){
          status.textContent = '✅ Radicado ' + out.radicado + ' creado';
          pqrsForm.reset();
        } else {
          status.textContent = '❌ Error al guardar';
        }
      }catch(err){ status.textContent = '❌ Error de conexión'; }
    });

    const btnLoadMine = document.getElementById('btnLoadMine');
    const mineList = document.getElementById('mineList');
    btnLoadMine?.addEventListener('click', async () => {
      mineList.innerHTML = 'Cargando...';
      try{
        const res = await fetch('/api/pqrs?scope=mine&user='+encodeURIComponent(user));
        const data = await res.json();
        if(!Array.isArray(data) || data.length===0){ mineList.innerHTML = '<div class="muted small">No hay registros</div>'; return; }
        mineList.innerHTML = '';
        data.slice().reverse().forEach(d => {
          const fechaStr = new Date(d.fecha).toLocaleString();
          const seg = d.seguimiento || {};
          const div = document.createElement('div');
          div.className = 'pqrs-item';
          div.innerHTML = `<strong>${escapeHtml(d.radicado)}</strong> <span class="muted small">(${escapeHtml(d.tipo)} · ${fechaStr})</span>
            <div>${escapeHtml(d.mensaje)}</div>
            <div class="muted small">Estado: ${escapeHtml(seg.estado||'Pendiente')} · Acción: ${escapeHtml(seg.tipoAccion||'-')} · Fecha: ${seg.fechaProgramada ? new Date(seg.fechaProgramada).toLocaleString() : '-'}</div>`;
          mineList.appendChild(div);
        });
      }catch(e){ mineList.innerHTML = '<div class="muted small">Error cargando</div>'; }
    });

    document.getElementById('btnExportMine')?.addEventListener('click', async () => {
      try{
        const res = await fetch('/api/pqrs?scope=mine&user='+encodeURIComponent(user));
        const data = await res.json();
        if(!Array.isArray(data) || data.length===0){ alert('No hay registros'); return; }
        const rows = [['radicado','tipo','mensaje','fecha','estado','accion','fechaProgramada']];
        data.forEach(r=> rows.push([r.radicado,r.tipo,r.mensaje,r.fecha, (r.seguimiento||{}).estado,(r.seguimiento||{}).tipoAccion,(r.seguimiento||{}).fechaProgramada]));
        const csv = rows.map(r=> r.map(c=> '"'+String(c||'').replace(/"/g,'""')+'"').join(',')).join('\n');
        const blob = new Blob([csv],{type:'text/csv;charset=utf-8;'});
        const a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='mis_pqrs.csv'; a.click();
      }catch(e){ alert('Error exportando'); }
    });
  }

  // ADMIN PAGE
  if (location.pathname.endsWith('/admin.html')) {
    const allList = document.getElementById('allList');
    async function loadAll(){
      allList.innerHTML = 'Cargando...';
      try{
        const res = await fetch('/api/pqrs?scope=all');
        const data = await res.json();
        window.__ALL__ = data || [];
        if(!Array.isArray(data) || data.length===0){ allList.innerHTML = '<div class="muted small">Sin registros</div>'; return; }
        const m = {Pendiente:0, 'En proceso':0, 'Cerrado':0};
        data.forEach(d=> m[d.seguimiento?.estado || 'Pendiente'] = (m[d.seguimiento?.estado || 'Pendiente']||0) + 1);
        document.getElementById('kOpen').textContent = String(m['Pendiente']||0);
        document.getElementById('kProc').textContent = String(m['En proceso']||0);
        document.getElementById('kClose').textContent = String(m['Cerrado']||0);

        allList.innerHTML = '';
        data.slice().reverse().forEach(d => {
          const fechaStr = new Date(d.fecha).toLocaleString();
          const seg = d.seguimiento || {};
          const div = document.createElement('div');
          div.className = 'pqrs-item';
          div.innerHTML = `<strong>${escapeHtml(d.radicado)}</strong> <span class="muted small">(${escapeHtml(d.tipo)} · ${fechaStr})</span>
            <div>${escapeHtml(d.mensaje)}</div>
            <div class="muted small">Cliente: ${escapeHtml(d.owner)} · Estado: ${escapeHtml(seg.estado||'Pendiente')} · Acción: ${escapeHtml(seg.tipoAccion||'-')} · Fecha: ${seg.fechaProgramada ? new Date(seg.fechaProgramada).toLocaleString() : '-'}</div>`;
          allList.appendChild(div);
        });
      }catch(e){ allList.innerHTML = '<div class="muted small">Error cargando</div>'; }
    }
    document.getElementById('btnLoadAll')?.addEventListener('click', loadAll);
    loadAll();

    document.getElementById('btnExportAll')?.addEventListener('click', async () => {
      try{
        const res = await fetch('/api/pqrs?scope=all');
        const data = await res.json();
        if(!Array.isArray(data) || data.length===0){ alert('No hay registros'); return; }
        const rows = [['radicado','owner','tipo','mensaje','fecha','estado','accion','fechaProgramada']];
        data.forEach(r=> rows.push([r.radicado,r.owner,r.tipo,r.mensaje,r.fecha, (r.seguimiento||{}).estado,(r.seguimiento||{}).tipoAccion,(r.seguimiento||{}).fechaProgramada]));
        const csv = rows.map(r=> r.map(c=> '"'+String(c||'').replace(/"/g,'""')+'"').join(',')).join('\n');
        const blob = new Blob([csv],{type:'text/csv;charset=utf-8;'});
        const a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='pqrs_todos.csv'; a.click();
      }catch(e){ alert('Error exportando'); }
    });

    const editForm = document.getElementById('editForm');
    editForm?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = document.getElementById('editId').value.trim();
      const estado = document.getElementById('editEstado').value;
      const accion = document.getElementById('editAccion').value;
      const fecha = document.getElementById('editFecha').value;
      const msg = document.getElementById('editMsg');
      msg.textContent = 'Guardando...';
      try{
        const res = await fetch('/api/pqrs/'+encodeURIComponent(id), {
          method:'PUT', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ estado, accion, fecha })
        });
        const out = await res.json();
        if(out.success){ msg.textContent = '✅ Actualizado'; editForm.reset(); loadAll(); }
        else { msg.textContent = '❌ '+(out.message||'Error'); }
      }catch(e){ msg.textContent = '❌ Error de conexión'; }
    });
  }

  document.getElementById('btnLogout')?.addEventListener('click', () => {
    localStorage.removeItem('jx_user'); localStorage.removeItem('jx_role');
    location.href = '/';
  });
});
